import 'package:flutter/material.dart';

// Colors
const kPrimaryColor = Color(0xFF6C63FF);
const kSecondaryColor = Color(0xFF95E1D3);
const kBackgroundColor = Color(0xFFF8F9FE);
const kCardColor = Colors.white;
const kTextPrimary = Color(0xFF2D3748);
const kTextSecondary = Color(0xFF718096);
const kAccentColor = Color(0xFFFFB6C1);

// Gradient
const kPrimaryGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [kPrimaryColor, kSecondaryColor],
);

// Storage keys
const String KEY_USER = 'daily_notes_user';
const String KEY_NOTES = 'notes';