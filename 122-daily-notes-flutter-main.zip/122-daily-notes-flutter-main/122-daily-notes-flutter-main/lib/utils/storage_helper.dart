import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/note_model.dart';
import 'constants.dart';

class StorageHelper {
  static final StorageHelper _instance = StorageHelper._internal();
  factory StorageHelper() => _instance;
  StorageHelper._internal();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  SharedPreferences get prefs {
    if (_prefs == null) {
      throw Exception('StorageHelper not initialized');
    }
    return _prefs!;
  }

  // === USER METHODS ===
  Future<bool> saveUser(String username) async {
    return await prefs.setString(KEY_USER, username);
  }

  String? getUser() {
    return prefs.getString(KEY_USER);
  }

  Future<bool> removeUser() async {
    return await prefs.remove(KEY_USER);
  }

  bool isLoggedIn() {
    return getUser() != null;
  }

  // === NOTES METHODS ===
  Future<bool> saveNotes(List<Note> notes) async {
    final List<String> notesJson = notes
        .map((note) => json.encode(note.toJson()))
        .toList();
    return await prefs.setStringList(KEY_NOTES, notesJson);
  }

  List<Note> getNotes() {
    final List<String>? notesJson = prefs.getStringList(KEY_NOTES);
    
    if (notesJson == null || notesJson.isEmpty) {
      return [];
    }

    return notesJson
        .map((noteStr) => Note.fromJson(json.decode(noteStr)))
        .toList();
  }

  Future<bool> addNote(Note note) async {
    final notes = getNotes();
    notes.add(note);
    return await saveNotes(notes);
  }

  Future<bool> updateNote(Note updatedNote) async {
    final notes = getNotes();
    final index = notes.indexWhere((n) => n.id == updatedNote.id);
    
    if (index != -1) {
      notes[index] = updatedNote;
      return await saveNotes(notes);
    }
    return false;
  }

  Future<bool> deleteNote(String id) async {
    final notes = getNotes();
    notes.removeWhere((n) => n.id == id);
    return await saveNotes(notes);
  }

  Future<bool> clearAll() async {
    return await prefs.clear();
  }
}