package com.example.daily_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
